﻿namespace Reservation.Models.DTO
{
    public class BookingDTO:Booking
    {
    }
}
