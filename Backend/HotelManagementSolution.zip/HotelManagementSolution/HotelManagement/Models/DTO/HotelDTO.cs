﻿namespace HotelManagement.Models.DTO
{
    public class HotelDTO:Hotel
    {
      
    }
}
