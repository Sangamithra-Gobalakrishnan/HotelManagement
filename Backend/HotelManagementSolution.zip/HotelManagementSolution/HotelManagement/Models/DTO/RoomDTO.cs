﻿namespace HotelManagement.Models.DTO
{
    public class RoomDTO:Room
    {

    }
}
