﻿namespace HotelManagement.Models.DTO
{
    public class AmenityOrImageDTO
    {
        public int HotelId { get; set; }
        public string? AmenityTypeOrImage { get; set; }
    }
}
