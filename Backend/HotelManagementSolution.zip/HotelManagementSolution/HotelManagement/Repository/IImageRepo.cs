﻿namespace HotelManagement.Repository
{
    public class IImageRepo
    {
    }
}
