﻿namespace Reservation.Models.DTO
{
    public class BookingId
    {
        public int UserId { get;set; }
    }
}
